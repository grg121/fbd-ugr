DROP TABLE city;
Drop Table Country;
drop table countrylanguage;

