
CREATE TABLE city (
  ID INT NOT NULL,
  Nombre CHAR(35) NOT NULL,
  CountryCode CHAR(3) NOT NULL,
  District CHAR(20) NOT NULL,
  Population INT NOT NULL,
  PRIMARY KEY (ID),
  CONSTRAINT city_ibfk_1 FOREIGN KEY (CountryCode) REFERENCES country (Code)
);

CREATE TABLE country (
  Code CHAR(3) NOT NULL,
  nombre CHAR(52) NOT NULL,
  Continent VARCHAR(20) CHECK (Continent in ('Asia','Europe','North America','Africa','Oceania','Antarctica','South America')),
  Region CHAR(26) NOT NULL,
  SurfaceArea NUMBER(10,2) NOT NULL,
  IndepYear INT,
  Population INT NOT NULL,
  LifeExpectancy NUMBER(3,1) ,
  GNP NUMBER(10,2),
  GNPOld NUMBER(10,2),
  LocalName CHAR(45) NOT NULL,
  GovernmentForm CHAR(45) NOT NULL,
  HeadOfState CHAR(60) DEFAULT NULL,
  Capital INT DEFAULT NULL,
  Code2 CHAR(2) NOT NULL,
  PRIMARY KEY (Code)
);


CREATE TABLE countrylanguage (
  CountryCode CHAR(3) NOT NULL,
  lang CHAR(30) NOT NULL,
  IsOfficial CHAR(1) CHECK(IsOfficial IN ('T','F')),
  Percentage NUMBER(4,1) NOT NULL,
  PRIMARY KEY (CountryCode,lang),
  CONSTRAINT countryLanguage_ibfk_1 FOREIGN KEY (CountryCode) REFERENCES country (Code)
);
