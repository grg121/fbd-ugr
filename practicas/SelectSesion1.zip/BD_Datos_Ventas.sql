REM INSERTING into VENTAS
SET DEFINE OFF;
Insert into VENTAS (CODPRO,CODPIE,CODPJ,CANTIDAD,FECHA) values ('S1 ','P1 ','J1 ',150,to_date('18/09/97','DD/MM/RR'));
Insert into VENTAS (CODPRO,CODPIE,CODPJ,CANTIDAD,FECHA) values ('S1 ','P1 ','J2 ',100,to_date('06/05/96','DD/MM/RR'));
Insert into VENTAS (CODPRO,CODPIE,CODPJ,CANTIDAD,FECHA) values ('S1 ','P1 ','J3 ',500,to_date('06/05/96','DD/MM/RR'));
Insert into VENTAS (CODPRO,CODPIE,CODPJ,CANTIDAD,FECHA) values ('S1 ','P2 ','J1 ',200,to_date('22/07/95','DD/MM/RR'));
Insert into VENTAS (CODPRO,CODPIE,CODPJ,CANTIDAD,FECHA) values ('S2 ','P2 ','J2 ',15,to_date('23/11/04','DD/MM/RR'));
Insert into VENTAS (CODPRO,CODPIE,CODPJ,CANTIDAD,FECHA) values ('S4 ','P2 ','J3 ',1700,to_date('28/11/00','DD/MM/RR'));
Insert into VENTAS (CODPRO,CODPIE,CODPJ,CANTIDAD,FECHA) values ('S1 ','P3 ','J1 ',800,to_date('22/07/95','DD/MM/RR'));
Insert into VENTAS (CODPRO,CODPIE,CODPJ,CANTIDAD,FECHA) values ('S5 ','P3 ','J2 ',30,to_date('01/04/14','DD/MM/RR'));
Insert into VENTAS (CODPRO,CODPIE,CODPJ,CANTIDAD,FECHA) values ('S1 ','P4 ','J1 ',10,to_date('22/07/95','DD/MM/RR'));
Insert into VENTAS (CODPRO,CODPIE,CODPJ,CANTIDAD,FECHA) values ('S1 ','P4 ','J3 ',250,to_date('09/03/94','DD/MM/RR'));
Insert into VENTAS (CODPRO,CODPIE,CODPJ,CANTIDAD,FECHA) values ('S2 ','P5 ','J2 ',300,to_date('23/11/04','DD/MM/RR'));
Insert into VENTAS (CODPRO,CODPIE,CODPJ,CANTIDAD,FECHA) values ('S2 ','P2 ','J1 ',4500,to_date('15/08/04','DD/MM/RR'));
Insert into VENTAS (CODPRO,CODPIE,CODPJ,CANTIDAD,FECHA) values ('S3 ','P1 ','J1 ',90,to_date('09/06/04','DD/MM/RR'));
Insert into VENTAS (CODPRO,CODPIE,CODPJ,CANTIDAD,FECHA) values ('S3 ','P2 ','J1 ',190,to_date('12/04/02','DD/MM/RR'));
Insert into VENTAS (CODPRO,CODPIE,CODPJ,CANTIDAD,FECHA) values ('S3 ','P5 ','J3 ',20,to_date('28/11/00','DD/MM/RR'));
Insert into VENTAS (CODPRO,CODPIE,CODPJ,CANTIDAD,FECHA) values ('S4 ','P5 ','J1 ',15,to_date('12/04/02','DD/MM/RR'));
Insert into VENTAS (CODPRO,CODPIE,CODPJ,CANTIDAD,FECHA) values ('S4 ','P3 ','J1 ',100,to_date('12/04/02','DD/MM/RR'));
Insert into VENTAS (CODPRO,CODPIE,CODPJ,CANTIDAD,FECHA) values ('S4 ','P1 ','J3 ',1500,to_date('26/01/03','DD/MM/RR'));
Insert into VENTAS (CODPRO,CODPIE,CODPJ,CANTIDAD,FECHA) values ('S1 ','P4 ','J4 ',290,to_date('09/03/94','DD/MM/RR'));
Insert into VENTAS (CODPRO,CODPIE,CODPJ,CANTIDAD,FECHA) values ('S1 ','P2 ','J4 ',175,to_date('09/03/94','DD/MM/RR'));
Insert into VENTAS (CODPRO,CODPIE,CODPJ,CANTIDAD,FECHA) values ('S5 ','P1 ','J4 ',400,to_date('01/04/14','DD/MM/RR'));
Insert into VENTAS (CODPRO,CODPIE,CODPJ,CANTIDAD,FECHA) values ('S5 ','P3 ','J3 ',400,to_date('01/04/14','DD/MM/RR'));
Insert into VENTAS (CODPRO,CODPIE,CODPJ,CANTIDAD,FECHA) values ('S1 ','P5 ','J1 ',340,to_date('06/02/10','DD/MM/RR'));

