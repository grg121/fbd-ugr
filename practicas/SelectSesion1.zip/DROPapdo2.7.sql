DROP TABLE ventas;
DROP TABLE proyecto;
DROP TABLE pieza;
DROP TABLE proveedor;